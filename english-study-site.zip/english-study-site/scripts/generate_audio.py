#!/usr/bin/env python3
import json, shutil, subprocess, tempfile
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
TEXTS=ROOT/"data"/"texts.json"
AUDIO_DIR=ROOT/"assets"/"audio"
ANKI_DIR=ROOT/"anki"
def require(cmd):
    if shutil.which(cmd) is None:
        raise SystemExit(f"Comando não encontrado: {cmd}. Instale antes de rodar.")
require("espeak"); require("ffmpeg")
AUDIO_DIR.mkdir(parents=True, exist_ok=True); ANKI_DIR.mkdir(parents=True, exist_ok=True)
lessons=json.loads(TEXTS.read_text(encoding="utf-8"))
with tempfile.TemporaryDirectory() as tmpdir:
    tmp=Path(tmpdir)
    for lesson in lessons:
        for line in lesson["lines"]:
            wav=tmp/f'{line["id"]}.wav'
            mp3=AUDIO_DIR/line["audio"]
            subprocess.run(["espeak","-v","en-us","-s","145","-w",str(wav),line["text"]], check=True)
            subprocess.run(["ffmpeg","-y","-loglevel","error","-i",str(wav),"-codec:a","libmp3lame","-q:a","5",str(mp3)], check=True)
            shutil.copy2(mp3, ANKI_DIR/line["audio"])
            print(f"OK: {line['audio']}")
print("Áudios gerados para o site e para /anki.")
