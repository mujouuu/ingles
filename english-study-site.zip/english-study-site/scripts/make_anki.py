#!/usr/bin/env python3
import csv, json
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
DATA=ROOT/"data"
ANKI=ROOT/"anki"
ANKI.mkdir(exist_ok=True)
def clean(v): return str(v).replace("\t"," ").replace("\n","<br>").replace("\r"," ")
def write_tsv(path, rows):
    with path.open("w", encoding="utf-8", newline="") as f:
        csv.writer(f, delimiter="\t").writerows([[clean(x) for x in row] for row in rows])
texts=json.loads((DATA/"texts.json").read_text(encoding="utf-8"))
grammar=json.loads((DATA/"grammar.json").read_text(encoding="utf-8"))
line_rows=[["Front","Back_PT","Grammar","Explanation","Audio","Tags"]]
for lesson in texts:
    for line in lesson["lines"]:
        tag=line["grammar"].replace(" ","_").replace("/","_")
        line_rows.append([line["text"], f'{line["pt"]}<br><br>{line["explanation"]}', line["grammar"], line["explanation"], f'[sound:{line["audio"]}]', f'english_line {lesson["id"]} {tag}'])
grammar_rows=[["Front","Back_PT","Pattern","Examples","Tags"]]
for item in grammar:
    grammar_rows.append([f'{item["title"]}<br><br>{item["pattern"]}', f'<strong>Uso:</strong> {item["use"]}<br><strong>Explicação:</strong> {item["explanation"]}<br><strong>Nota:</strong> {item["ptNote"]}', item["pattern"], "<br>".join(item["examples"]), f'grammar_130 {item["category"].replace(" ","_")}'])
write_tsv(ANKI/"english_lines.tsv", line_rows)
write_tsv(ANKI/"grammar_130.tsv", grammar_rows)
print("Arquivos gerados em /anki")
